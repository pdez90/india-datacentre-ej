India data-centre facility inventory, v2 (revised 30 September 2026)
=====================================================================
Companion data to: deSouza, P., et al. "Data centers in India locate in affluent districts while
their environmental impacts extend through shared regional systems." Explorer and code:
https://github.com/pdez90/india-datacentre-ej   Contact: priyanka.desouza@ucdenver.edu
Packaged 2026-10-02.

Licence: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/). Credit required;
no commercial use without permission.

Please cite as:
  deSouza, P., et al. (2026). India data-centre facility inventory, v2 (30 September 2026)
  [Data set]. https://github.com/pdez90/india-datacentre-ej

Files
-----
india_datacentres_public.csv   340 facilities, one row each: name, operator, type, status, city,
                               district and state, reported and modelled IT capacity, the source
                               URL(s) with archived copies, how each row was verified, confidence,
                               corrections and open issues, and the cross-check against the Atlas
                               of Data Center Politics. No coordinates (city/district precision).
sources_and_archives.csv       every URL cited (552), the facilities that cite it, and its archived
                               copy (Internet Archive or archive.today) with the snapshot date.
DATA.md                        data dictionary and methods: what a row is, where rows come from,
                               every column, how capacity was set, and the version history.

Archiving
---------
465 of 552 cited URLs have an archived copy. 338 of 340 facilities have at least one
archived source. The 87 URLs without a copy are on sites that block web archives (chiefly
datacentermap.com) or were unreachable from the archives; archive_status says which. Links were checked and
archived between 30 September and 2 October 2026.
