India data-centre facility inventory (revised 30 September 2026)
================================================================
Companion data to: deSouza, P., et al. "The Environmental Geography of Data Centers in India."
Explorer and code:
https://github.com/pdez90/india-datacentre-ej   Contact: priyanka.desouza@ucdenver.edu
Packaged 2026-10-21.

Licence: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/). Credit required;
no commercial use without permission.

Please cite as:
  deSouza, P., et al. (2026). India data-centre inventory (public facility table), version
  2026-09-30 [Data set]. https://github.com/pdez90/india-datacentre-ej

Files
-----
india_datacentres_public.csv   340 facilities, one row each: name, operator, type, status, city,
                               district and state, reported and modelled IT capacity, the source
                               URL(s) with archived copies, how each row was verified, confidence,
                               corrections and open issues, and the cross-check against the Atlas
                               of Data Center Politics. Site coordinates with their precision class.
sources_and_archives.csv       every URL cited (551), the facilities that cite it, and its archived
                               copy (Internet Archive or archive.today) with the snapshot date.
DATA.md                        data dictionary and methods: what a row is, where rows come from,
                               every column, how capacity was set, and the corrections made.
power_interruptions_backup_diesel.csv (+ _README.txt)
                               per hosting district: ESMI interruption hours, the hours the
                               backup-diesel model used and why, and the resulting emissions.
emission_factors.csv (+ _README.txt)
                               every emission and water factor used, with unit, source and script.

Archiving
---------
548 of 551 cited URLs have an archived copy. 340 of 340 facilities have at least one
archived source. Data Center Map pages the Internet Archive could not capture (81 of 245) and 5 IndiaMART
pages were archived on archive.today by hand by 10 October 2026. The 3 URLs without a copy are on Indian government and
company servers reachable only from Indian networks, so neither archive could capture them; each is a facility's
second source, and source_note in the facility table records what the authors hold for it. Links were checked and
archived between 30 September and 20 October 2026.
